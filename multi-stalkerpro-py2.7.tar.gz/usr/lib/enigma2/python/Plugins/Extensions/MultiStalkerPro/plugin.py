# -*- coding: UTF-8 -*-
from Plugins.Plugin import PluginDescriptor
from enigma import addFont, getFontFaces
from Plugins.Extensions.MultiStalkerPro.__init__ import loadPluginSkin
from Plugins.Extensions.MultiStalkerPro.MultiStalkerPro import main, autostart
from Plugins.Extensions.MultiStalkerPro.MultiStalkerProSetup import conf

addFont("/usr/lib/enigma2/python/Plugins/Extensions/MultiStalkerPro/assets/fonts/google-icons.ttf", "M-icons", 90, 1)
addFont("/usr/lib/enigma2/python/Plugins/Extensions/MultiStalkerPro/assets/fonts/font_default.otf", "ArabicFont", 100, 1)
if 'Bold' not in getFontFaces():
    addFont("/usr/lib/enigma2/python/Plugins/Extensions/MultiStalkerPro/assets/fonts/M-Bold.ttf", "Bold", 100, 1)


def showInmenu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("Multi-StalkerPro", main, "Multi-StalkerPro", 1)]
    else:
        return []


def Plugins(**kwargs):
    loadPluginSkin()
    Descriptors = []
    if conf.mainmenu.value:
        Descriptors.append(PluginDescriptor(where=[PluginDescriptor.WHERE_MENU], fnc=showInmenu))
    Descriptors.append(PluginDescriptor(where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart))
    Descriptors.append(PluginDescriptor(name="Multi-StalkerPro", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main))
    Descriptors.append(PluginDescriptor(name='Multi-StalkerPro', description='Multi-StalkerPro Portals By ZIKO', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon='icon.png'))
    return Descriptors
